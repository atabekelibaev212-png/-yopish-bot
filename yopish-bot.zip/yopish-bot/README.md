# Yopish — Telegram Mini App + Bot

Tap-to-earn coin ilovasi: bosish orqali tanga yig'ish, skinlar do'koni, vazifalar,
referral tizimi, kunlik bonus, auksion, real-time shashka o'yini va admin panel.

## ⚠️ Muhim eslatma

Ushbu loyihada **haqiqiy pul evaziga tasodifiy yutuq beruvchi baraban** va
**kartaga to'g'ridan-to'g'ri pul yig'ib, chekni qo'lda tasdiqlash** funksiyalari
**ataylab qo'shilmagan** — bunday tizim qimor/lotereya sifatida qonunga zid bo'lishi
mumkin. Buning o'rniga:

- Barcha "olmos" tizimi olib tashlandi, faqat **coin** (in-game valyuta) ishlatiladi
- Coin faqat bosish, vazifalar, referral va kunlik bonus orqali topiladi
- Agar kelajakda haqiqiy to'lovni qo'shmoqchi bo'lsangiz, buni faqat **rasmiy
  litsenziyalangan to'lov tizimi** (Payme yoki Click Merchant API) orqali, sotib
  olingan narsa **belgilangan** (tasodifiy bo'lmagan) tovar/xizmat bo'lgandagina qiling.

## Talab qilinadigan narsalar

- Node.js 18+ o'rnatilgan bo'lishi kerak
- @BotFather orqali yaratilgan bot va uning **tokeni**
- Mini App joylash uchun **HTTPS manzil** (masalan: Render.com, Railway.app, yoki
  o'z VPS serveringiz + domen + SSL). Telegram Mini App faqat HTTPS bilan ishlaydi,
  localhost bilan ishlamaydi (faqat brauzerda test qilish uchun localhost mumkin).

## O'rnatish

```bash
cd backend
npm install
cp .env.example .env
```

`.env` faylini oching va to'ldiring:

```
BOT_TOKEN=@BotFather bergan tokeningiz
WEBAPP_URL=https://sizning-domeningiz.com
ADMIN_IDS=sizning_telegram_user_id_raqamingiz
PORT=3000
```

> Telegram user ID raqamingizni bilish uchun Telegram ichida **@userinfobot** ga
> yozing, u sizga ID raqamingizni beradi.

## Ishga tushirish (lokal test)

```bash
npm start
```

Server `http://localhost:3000` da ishga tushadi. Bot polling rejimida ishlaydi —
Telegram'da botingizga `/start` yozib sinab ko'rishingiz mumkin (agar `WEBAPP_URL`
haqiqiy HTTPS manzil bo'lsa, "Mini App ochish" tugmasi ishlaydi).

## Serverga joylashtirish (production)

1. Ushbu `backend` papkasini serveringizga (Render/Railway/VPS) yuklang
2. Environment variables (`BOT_TOKEN`, `WEBAPP_URL`, `ADMIN_IDS`) ni sozlang
3. `npm install && npm start` (yoki platforma o'zi buni avtomatik bajaradi)
4. `WEBAPP_URL` — sizning HTTPS domeningiz bo'lishi kerak (masalan
   `https://yopish.onrender.com`), chunki backend shu manzil orqali
   `public/` papkasidagi Mini App'ni ham xizmat qiladi (`express.static`)
5. @BotFather'ga o'ting → botingiz → **Bot Settings → Menu Button** → shu HTTPS
   manzilni kiriting, shunda foydalanuvchilar tugma orqali ham Mini App'ni
   ocha oladi

## Loyihaning tuzilishi

```
backend/
  server.js       — Express API server + barcha endpointlar
  bot.js          — Telegraf bot (Telegram bilan aloqa)
  db.js           — Fayl-asosli oddiy baza (data/db.json)
  checkers.js     — Shashka o'yin dvigateli + socket.io
  data/db.json    — Barcha ma'lumotlar shu yerda saqlanadi (avtomatik yaratiladi)
public/
  index.html      — Mini App interfeysi (barcha ekranlar)
  style.css       — Dizayn
  app.js          — Frontend logika
```

## Xususiyatlar

### Foydalanuvchilar uchun
- **Bosish (Tap)** — energiya sarflab coin yig'ish, skinga qarab ko'paytiruvchi (x1–x10)
- **Boost / Do'kon** — coin evaziga anime-mavzu skinlar sotib olish (bosganda ko'proq coin beradi)
- **Vazifalar** — admin qo'shgan vazifalarni bajarib coin olish (kanalga a'zo bo'lish va h.k.)
- **Referral** — do'stni taklif kodi orqali taklif qilib, ikkalangizga ham bonus
- **Kunlik bonus** — har kuni admin bergan kodni kiritib bonus olish
- **Auksion** — coin evaziga tender qatnashish
- **Shashka** — boshqa foydalanuvchi bilan real-time o'ynash, o'yin kodi orqali
  do'stingizni taklif qilishingiz mumkin

### Admin uchun (faqat `.env` dagi `ADMIN_IDS` da ko'rsatilgan userlarga ko'rinadi)
- Bot statistikasi (foydalanuvchilar soni, umumiy coin va h.k.)
- Yangi vazifa qo'shish/o'chirish
- Kunlik bonus kodini o'zgartirish
- Yangi auksion yaratish
- Foydalanuvchilar ro'yxati, coin balansini qo'lda tuzatish (support uchun), ban qilish
- Bot ichida `/admin` va `/setdailycode KOD` buyruqlari ham mavjud

## Kengaytirish g'oyalari

- Rasmiy Payme/Click to'lov integratsiyasi qo'shib, coin sotib olishni yoqish mumkin
- Push-xabarlar (bot orqali barcha foydalanuvchilarga e'lon yuborish)
- Ko'proq vazifa turlari (screenshot yuklash, kod kiritish va h.k.)
- Reyting jadvali (leaderboard)
